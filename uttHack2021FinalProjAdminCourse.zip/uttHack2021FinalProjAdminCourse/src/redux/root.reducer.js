import {combineReducers} from 'redux';
import {COURSE_FEATURE_KEY, courseReducer} from "./courses/courses.reducer";
let rootReducer = combineReducers({
  [COURSE_FEATURE_KEY]: courseReducer
});
export {rootReducer};