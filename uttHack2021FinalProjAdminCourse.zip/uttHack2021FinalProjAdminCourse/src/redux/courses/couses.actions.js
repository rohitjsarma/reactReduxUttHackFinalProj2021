import {FETCH_COURSE_FAILURE, FETCH_COURSE_REQUEST, FETCH_COURSE_SUCCESS} from "./courses.actionTypes";
import Axios  from  'axios';



let fetchCourseRequest=()=>{
    return{
        type:FETCH_COURSE_REQUEST
    }
};
let fetchCourseSuccess=(courses)=>{
    return{
        type:FETCH_COURSE_SUCCESS,
        payload:courses
    }
};
let fetchCourseFailure=(error)=>{
    return{
        type:FETCH_COURSE_FAILURE,
        payload:error
    }
};


let fetchCourses=()=>{
    return(dispatch)=>{
        dispatch(fetchCourseRequest());
        Axios.get('https://gist.githubusercontent.com/rohitjsarma/70deb81d4fa26b9ed983f1c7bd6e01de/raw/ab33101db25a01e00423a8700c2ed2130ea751e8/courseListTwo').then((response)=>{
            dispatch(fetchCourseSuccess(response.data))
        }).catch((error)=>{
            dispatch(fetchCourseFailure(error))
        });
    }
}
export {fetchCourses};


