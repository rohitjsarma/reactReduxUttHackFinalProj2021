import React,{useState} from "react";
import {useDispatch, useSelector} from "react-redux";
import {fetchCourses} from "../redux/courses/couses.actions";
import {COURSE_FEATURE_KEY} from "../redux/courses/courses.reducer";


let CourseList=()=>{

    let dispatch = useDispatch();

    let courseInfo= useSelector((state)=>{
        return  state[COURSE_FEATURE_KEY];
    })

    let getData=()=>{
        dispatch(fetchCourses());
    };

    return(
        <React.Fragment>
            <div className="container mt-5">
                <div className="row">
                    <div className="col">
                        <div className="card">
                            <div className="card-header">

                                <form >
                                    <label htmlFor="course">Choose from home:</label>

                                    <select name="course" id="Course" >
                                        <option value="tt" >Tutor</option>
                                        <option value="crs" onChange={getData} >Course</option>
                                        <option value="cul">Certified User List</option>
                                        <option value="lo">Logout</option>
                                    </select>

                                </form>


                            </div>
                            <div className="card-body">
                                <button onClick={getData} className='btn btn-warning btn-sm'>Get Data </button>
                            <table className='table table-primary table-hover text-center table-striped'>
                                <thead className='bg-primary text-white'>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Tutor</th>
                                    <th>Gender</th>
                                    <th>Attendee</th>

                                </tr>

                                </thead>
                                <tbody>
                                {
                                    courseInfo.courses.length>0?<React.Fragment>
                                        {
                                            courseInfo.courses.map((user)=>{
                                                return(
                                                    <tr key={user.id}>
                                                        <td>{user.id}</td>
                                                        <td>{user.name}</td>
                                                        <td>{user.tutor}</td>
                                                        <td>{user.gender}</td>
                                                        <td>{user.attendee} <a href='https://www.w3schools.com/'>  view</a></td>




                                                    </tr>
                                                )
                                            })
                                        }


                                    </React.Fragment>:null
                                }
                                </tbody>

                            </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </React.Fragment>
    )
}
export default CourseList;